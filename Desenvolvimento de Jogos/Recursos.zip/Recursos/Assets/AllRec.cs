﻿using UnityEngine;
using UnityEngine.UI;

public class AllRec : MonoBehaviour
{
    private Text texto;
    public int total;

    private void Start() {
        texto = GetComponent<Text>();
    }

    private void Update() {
        texto.text = "Recursos: " + total;
    }
}
