﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Worker : MonoBehaviour {

    public int skill = 8;
    public float resourceCatch;
    private TaskContainer task;
    private NavMeshAgent ia;
    private Animator _am;

    private TaskDeposit deposit;

    public Animator Am => _am;

    private readonly List<string> workable = new List<string> { "Trabalho", "Deposito" };


    private void Awake() {
        task = GameObject.FindGameObjectWithTag("Trabalho").GetComponent<TaskContainer>();
        deposit = GameObject.FindGameObjectWithTag("Deposito").GetComponent<TaskDeposit>();
        ia = GetComponent<NavMeshAgent>();
        _am = GetComponent<Animator>();
    }

    private void Update() {
        //deposit.enabled = _am.GetBool("isCarring");
    }

    public void GoTo(Vector3 pos) => ia.SetDestination(pos);

    private void DoWork() {
        task.Trabalho = skill;
    }

    private void DoDeposit() {
        deposit.Trabalho = skill;
    }

    public void OnTriggerEnter(Collider other) {
        if (!workable.Contains(other.tag)) { return; }

        string exec = other.tag == "Trabalho" ? "DoWork" : "DoDeposit";

        InvokeRepeating(exec, 2.0f, 1.0f);
    }
}

