﻿using UnityEngine;

[CreateAssetMenu(fileName = "Task", menuName = "Task", order = 1)]
public class TaskBase : ScriptableObject {
    public string nome;
    public int trabalhoMax;
    public int recursosTotal;
}