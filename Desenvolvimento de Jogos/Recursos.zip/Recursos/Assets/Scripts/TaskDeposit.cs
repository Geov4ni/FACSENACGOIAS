﻿using UnityEngine;
using UnityEngine.UI;

public class TaskDeposit : MonoBehaviour {

    private Worker worker;

    public AllRec rec;

    private float depositoAtual;

    public int Trabalho {
        get => (int)depositoAtual;
        set => depositoAtual -= !IsDone ? value: 0;
    }

    public bool IsDone => depositoAtual <= .0f;

    private Text nome;
    private Text done;
    private GameObject atividade;
    private Text somaRec;
    private Slider progress;

    private void Awake() {
        worker = GameObject.Find("Farmer").GetComponent<Worker>();

        nome = GameObject.Find("Nome").GetComponent<Text>();
        done = GameObject.Find("Completada").GetComponent<Text>();
        somaRec = GameObject.Find("somaRecursos").GetComponent<Text>();
        progress = GameObject.Find("Porcentagem").GetComponent<Slider>();

        rec = GameObject.Find("somaRecursos").GetComponent<AllRec>();
    }

    private void OnTriggerEnter(Collider other) {
        worker.Am.SetBool("isDepositing", true);
        nome.text = "Depositando";
        depositoAtual = 20;
        progress.maxValue = worker.resourceCatch;

    }

    private void OnTriggerStay(Collider other) {
        if (worker.Am.GetBool("isCarring")) {
            if (IsDone) {
                done.text = "Completado";
                worker.Am.SetBool("isCarring", false);
                worker.Am.SetBool("isDepositing", false);

                rec.total += (int)worker.resourceCatch;
                worker.resourceCatch = 0f;

            } else {
                done.text = "Trabalhando...";
            }
        }
        progress.value = Trabalho;
    }
}
