﻿using UnityEngine;
using UnityStandardAssets.Characters.ThirdPerson;

public class ObjectPicker : MonoBehaviour {

    private ThirdPersonCharacter player;
    private AICharacterControl ia;
    private Worker wk;

    private void Awake() {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<ThirdPersonCharacter>();
        ia = GameObject.FindGameObjectWithTag("Player").GetComponent<AICharacterControl>();
        wk = GameObject.FindGameObjectWithTag("Player").GetComponent<Worker>();
    }

    private void Update() {
        if (player.m_Animator.GetBool("isWorking")) { return; }

        if (Input.GetMouseButtonDown(0)) {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out RaycastHit hit, 100)) {

                bool a = hit.transform.gameObject.name == "Ground";
                bool b = player.m_Animator.GetBool("isCarring") && hit.transform.gameObject.tag == "Trabalho";
                //bool c = player.m_Animator.GetBool("isWorking") && hit.transform.gameObject.name == "Deposito";
                if (a || b) { return; }

                ia.SetTarget(hit.transform);
            }
        }
    }
}
