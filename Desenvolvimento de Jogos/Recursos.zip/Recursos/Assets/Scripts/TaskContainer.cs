﻿using UnityEngine;
using UnityEngine.UI;

public class TaskContainer : MonoBehaviour {

    public TaskBase task;

    private Worker worker;

    private int trabalhoAtual;

    public int Trabalho {
        get => trabalhoAtual;
        set => trabalhoAtual += !IsDone ? value : 0;
    }

    public bool IsDone => trabalhoAtual >= task.trabalhoMax;

    private Text nome;
    private Text done;
    private GameObject atividade;
    private Slider progress;

    private void Start() {
        worker = GameObject.Find("Farmer").GetComponent<Worker>();

        nome = GameObject.Find("Nome").GetComponent<Text>();
        done = GameObject.Find("Completada").GetComponent<Text>();
        progress = GameObject.Find("Porcentagem").GetComponent<Slider>();
    }

    private void OnTriggerEnter(Collider other) {
        worker.Am.SetBool("isWorking", true);

        nome.text = task.nome;
        progress.maxValue = task.trabalhoMax;
    }

    private void OnTriggerStay(Collider other) {
        if (worker.Am.GetBool("isWorking")) {
            if (IsDone) {
                done.text = "Completado";
                worker.Am.SetBool("isWorking", false);
                worker.Am.SetBool("isCarring", true);

                worker.GoTo(GameObject.FindWithTag("Deposito").transform.position);
            } else {
                done.text = "Trabalhando...";
                worker.resourceCatch += task.recursosTotal;
            }
        }
        progress.value = Trabalho;
    }

    private void OnTriggerExit(Collider other) { trabalhoAtual = 0;}
}
