﻿using UnityEngine;
using UnityEngine.AI;

public class ButtonHandler : MonoBehaviour {
    private NavMeshAgent ia;
    private Vector3 trabalho;

    private void Start() {
        ia = GameObject.FindWithTag("Player").GetComponent<NavMeshAgent>();
        trabalho = GameObject.FindWithTag("Trabalho").transform.position;
    }

    public void Init() => ia.SetDestination(trabalho);
}
