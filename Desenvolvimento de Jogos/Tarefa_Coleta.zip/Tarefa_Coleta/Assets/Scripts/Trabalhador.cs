﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Trabalhador : MonoBehaviour
{
    private GameObject casa;
    private GameObject deposito;
    private GameObject colheita;
    private NavMeshAgent Navmesh;
    Tarefa tarefa;

    // Start is called before the first frame update
    void Start()
    {
        casa = GameObject.Find("Casa");
        deposito = GameObject.Find("Deposito");
        colheita = GameObject.Find("Colheita");
        Navmesh = GetComponent<NavMeshAgent>();
        tarefa = colheita.GetComponent<Tarefa>();

        Navmesh.SetDestination(casa.transform.position);
    }

    // Update is called once per frame
    void Update()
    {
        

        if (Vector3.Distance(transform.position, colheita.transform.position) < 1)
        {
            Navmesh.SetDestination(deposito.transform.position);
        }

        if (Vector3.Distance(transform.position, deposito.transform.position) < 1)
        {
            Navmesh.SetDestination(casa.transform.position);
        }


    }

    private void OnTriggerEnter(Collider other)
    {

        if(other.name == "Casa")
        {
            print("casa");

            if (Vector3.Distance(transform.position, casa.transform.position) < 1)
            {
                Navmesh.SetDestination(colheita.transform.position);
            }
        }
    }
}
