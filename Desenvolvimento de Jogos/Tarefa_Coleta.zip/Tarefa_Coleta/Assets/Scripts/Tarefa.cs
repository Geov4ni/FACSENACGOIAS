﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tarefa : MonoBehaviour
{

    public string nome;
    public int cargaTotal;
    public int recursosTotal;

    int cargaAtual = 0;
    int recustoAtual = 0;

    bool jobDone = false;

    public int gettrabalhoAtual()
    {
        return cargaAtual;
    }

    public int getRecursoAtual()
    {
        return recustoAtual;
    }

    public void executarTarefa(int valor)
    {
        if(cargaAtual < cargaTotal)
        {
            cargaAtual += valor;
        }

        if (cargaAtual > cargaTotal)
        {
            cargaAtual = cargaTotal;
        }
    }


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (cargaAtual >= cargaTotal)
        {
            jobDone = true;
        }
    }
}
