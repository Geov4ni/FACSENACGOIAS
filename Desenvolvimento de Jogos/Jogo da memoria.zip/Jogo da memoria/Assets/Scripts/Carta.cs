﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Carta : MonoBehaviour
{
    public int id;
    public Sprite imgFrente;
    public Sprite imgVerso;
    bool viradaParaCima;

    private GeradorCartas gc;

    void Start()
    {
        gc = GameObject.Find("Gerador").GetComponent<GeradorCartas>();
        viradaParaCima = false;
        //mudarImagem();
    }

    public void mudarImagem()
    {
        
        if (!viradaParaCima)
        {
            viradaParaCima = !viradaParaCima;
            GetComponent<UnityEngine.UI.Image>().sprite = imgFrente;
            print("0");
            gc.seleciona(gameObject);
        }
                
    }

    public void CartaVirada()
    {
        viradaParaCima = false;
        GetComponent<UnityEngine.UI.Image>().sprite = imgVerso;
    }

    
}
