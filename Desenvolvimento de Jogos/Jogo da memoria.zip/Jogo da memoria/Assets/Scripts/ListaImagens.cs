﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ListaImagens : MonoBehaviour
{
    public List<Sprite> imagens = new List<Sprite>(5);
}
