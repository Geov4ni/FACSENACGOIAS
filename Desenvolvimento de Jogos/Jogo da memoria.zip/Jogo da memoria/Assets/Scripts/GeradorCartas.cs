﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class GeradorCartas : MonoBehaviour
{
    List<GameObject> cartas = new List<GameObject>(10);
    public GameObject prefabCarta;
    public Transform canvas;

    public Text scoretxt;
    public Text jogadatxt;

    private GameObject primeira = null;
    private GameObject segunda = null;

    public int pontos = 0;
    public int jogadas = 0;

    // Start is called before the first frame update
    void Start()
    {
        
        canvas = GameObject.Find("Canvas1").transform;
        GameObject listaImagens = GameObject.Find("ListaImagens");
        int idCarta = 0;
        while (listaImagens.GetComponent<ListaImagens>().imagens.Count > 0)
        {
            int imgRandom = Random.Range(0, listaImagens.GetComponent<ListaImagens>().imagens.Count);

            Sprite imgFrente = listaImagens.GetComponent<ListaImagens>().imagens[imgRandom];
            listaImagens.GetComponent<ListaImagens>().imagens.RemoveAt(imgRandom);

            GameObject novaCarta1 = Instantiate(prefabCarta);
            GameObject novaCarta2 = Instantiate(prefabCarta);

            novaCarta1.GetComponent<Carta>().id = idCarta;
            novaCarta2.GetComponent<Carta>().id = idCarta;

            idCarta++;

            novaCarta1.GetComponent<Carta>().imgFrente = imgFrente;
            novaCarta2.GetComponent<Carta>().imgFrente = imgFrente;

            cartas.Add(novaCarta1);
            cartas.Add(novaCarta2);
        }

        embaralhar(cartas);

        foreach(GameObject cadaCarta in cartas)
        {
            cadaCarta.transform.SetParent(canvas, false);
        }


    }

    public void embaralhar(List<GameObject> lista)
    {
        int count = lista.Count;
        int last = count - 1;

        for (int i = 0; i < last; i++)
        {
            int r = Random.Range(i, count);
            GameObject temp = lista[i];
            lista[i] = lista[r];
            lista[r] = temp;
        }
    }

    public void seleciona(GameObject carta)
    {
        if (!primeira)
        {
            print("1");
            primeira = carta;
        }
        else if (!segunda)
        {
            print("2");
            segunda = carta;

            jogadas += 1;
        }

        if(primeira && segunda)
        {
            print("teste");
            Carta p, s;
            p = primeira.GetComponent<Carta>();
            s = segunda.GetComponent<Carta>();

            if (p.id == s.id)
            {
                pontos += 10;
            }
            else
            {
                StartCoroutine(Wait(p, s));
                                
            }

            Reset();
        }
    }

    private void Reset()
    {
        primeira = null;
        segunda = null;
    }

    private IEnumerator Wait(Carta p, Carta s)
    {
        print(Time.time);
        yield return new WaitForSecondsRealtime(1f);
        print(Time.time);

        p.CartaVirada();
        s.CartaVirada();
    }

    private void Update()
    {
        scoretxt.text = "Pontos: " + pontos;
        jogadatxt.text = "Jogadas: " + jogadas;
    }
}
